import json

json_file=open('data1.json')
data=json.load(json_file)

#print (data)

print("Monday")

for d in data:
    if(d[0]["dow"]=="Monday"):
        print(d[0],d[1],d[2])

print("\n")

print("Tuesday")

for d in data:
    if(d[0]["dow"]=="Tuesday"):
        print(d[0],d[1],d[2])


print("\n")

print("Wednesday")

for d in data:
    if(d[0]["dow"]=="Wednesday"):
        print(d[0],d[1],d[2])

        
print("\n")

print("Thursday")

for d in data:
    if(d[0]["dow"]=="Thursday"):
        print(d[0],d[1],d[2])
        
       

print("\n")

print("Friday")

for d in data:
    if(d[0]["dow"]=="Friday"):
        print(d[0],d[1],d[2])
        
 
       
