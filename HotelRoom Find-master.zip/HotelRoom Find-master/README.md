# extracting required data from json file
